package com.generated.api.model;

public class User {

    private String id;
    private String name;
    private String email;

}
