package com.generated.api.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {

    public String getSampleData() {
        return "Sample data for User";
    }
}
